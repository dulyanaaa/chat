export class Interest {
  constructor(
    public id: number,
    public channelId: number,
    public userId: number
  ) {}
}
